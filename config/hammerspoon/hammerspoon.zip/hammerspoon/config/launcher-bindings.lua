local network = function ()
  os.execute("open /System/Library/PreferencePanes/Network.prefPane")
end

local kill = function ()
  hs.window.frontmostWindow():application():kill()
end

local maximize = function ()
  local isFullScreen=hs.window.frontmostWindow():isFullScreen()
  hs.window.frontmostWindow():setFullScreen(not isFullScreen)
end

return {
  { 'p', '1Password 7' },
  { 'j', 'Slack' },
  { 'a', 'Canary Mail' },
  { 'f', 'Finder' },
  { 'g', 'Firefox' },
  { 'i', 'Alacritty' },
  { 'y', 'Spotify' },
  { 'd', 'Android Studio' },
  { 's', 'Sublime Merge' },
  { 't', 'Sublime Text' },
  { '-', 'Zzz' },
  { '7', 'Dash' },
  { 'r', 'Mission Control' },
  { 'v', 'IINA' },
  { 'h', 'AppCode 2019.3 EAP' },
  { 'l', 'GoLand' },
  { '0', network},
  { 'k', kill},
  { '=', maximize},
}
