typeMessage = { system = '🧩 ',
                launcher = '🐳 ',
                window = '📐 ',
                numeric = '🔢 ',
                markdown = '✍️ ',
                dafuck = '🚨 '}
