-- Default keybindings for WindowLayout Mode
--
-- To customize the key bindings for WindowLayout Mode, create a copy of this
-- file, save it as `windows-bindings.lua`, and edit the table below to
-- configure your preferred shortcuts.

--------------------------------------------------------------------------------
-- Define WindowLayout Mode
--
-- WindowLayout Mode allows you to manage window layout using keyboard shortcuts
-- that are on the home row, or very close to it. Use Control+s to turn
-- on WindowLayout mode. Then, use any shortcut below to perform a window layout
-- action. For example, to send the window left, press and release
-- Control+s, and then press h.
--
--   h/j/k/l => send window to the left/bottom/top/right half of the screen
--   i => send window to the upper left quarter of the screen
--   o => send window to the upper right quarter of the screen
--   , => send window to the lower left quarter of the screen
--   . => send window to the lower right quarter of the screen
--   return => make window full screen
--   n => send window to the next monitor
--   left => send window to the monitor on the left (if there is one)
--   right => send window to the monitor on the right (if there is one)
--------------------------------------------------------------------------------

return {
  modifiers = {'cmd','ctrl','alt','shift'},
  showHelp  = false,
  trigger   = ';',
  mappings  = {
    { {},                'b',      '/usr/local/bin/yabai -m space --balance' },
    { {},                'h',      '/usr/local/bin/yabai -m window --focus west' },
    { {},                'j',      '/usr/local/bin/yabai -m window --focus south' },
    { {},                'k',      "/usr/local/bin/yabai -m window --focus north" },
    { {},                'l',      '/usr/local/bin/yabai -m window --focus east' },
    { {'shift'},         'h',      '/usr/local/bin/yabai -m window --swap west' },
    { {'shift'},         'j',      '/usr/local/bin/yabai -m window --swap south' },
    { {'shift'},         'k',      "/usr/local/bin/yabai -m window --swap north" },
    { {'shift'},         'l',      '/usr/local/bin/yabai -m window --swap east' },
    { {'shift'},         '1',      '/usr/local/bin/yabai -m window --space  1; /usr/local/bin/yabai -m space --focus 1' },
    { {'shift'},         '2',      '/usr/local/bin/yabai -m window --space  2; /usr/local/bin/yabai -m space --focus 2' },
    { {'shift'},         '3',      '/usr/local/bin/yabai -m window --space  3; /usr/local/bin/yabai -m space --focus 3' },
    { {'shift'},         '4',      '/usr/local/bin/yabai -m window --space  4; /usr/local/bin/yabai -m space --focus 4' },
  }
}
