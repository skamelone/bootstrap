modifiers = {'cmd','ctrl','alt','shift'}
local passwordTrigger = hs.hotkey.bind(modifiers, "1", function()
  token_keystroke("pouet_password")
end)

passwordTrigger:disable()
hs.window.filter.new('1Password 7')
    :subscribe(hs.window.filter.windowFocused,function() passwordTrigger:enable() end)
    :subscribe(hs.window.filter.windowUnfocused,function() passwordTrigger:disable() end)

hs.window.filter.new('Firefox')
    :subscribe(hs.window.filter.windowFocused,function() passwordTrigger:enable() end)
    :subscribe(hs.window.filter.windowUnfocused,function() passwordTrigger:disable() end)


hs.hotkey.bind(modifiers, "2", function()
  token_keystroke("mac_password")
end)

hs.hotkey.bind(modifiers, "3", function()
  token_keystroke("cloud_password")
end)

function password_from_keychain(name)
	local cmd="/usr/bin/security 2>&1 >/dev/null find-generic-password -ga " .. name .. " | sed -En '/^password: / s,^password: \"(.*)\"$,\\1,p'"
    local handle = io.popen(cmd)
    local result = handle:read("*a")
    handle:close()
    return (result:gsub("^%s*(.-)%s*$", "%1"))
end

function token_keystroke(token_name)
    local token = password_from_keychain(token_name)
    hs.eventtap.keyStrokes(token)
end
