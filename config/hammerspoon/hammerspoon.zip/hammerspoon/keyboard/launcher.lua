local status, hyperModeAppMappings = pcall(require, 'config.launcher-bindings')

if not status then
  hyperModeAppMappings = require('config.launcher-bindings')
end

shyper = {"⌘", "⌥", "⌃", "⇧"}

for i, mapping in ipairs(hyperModeAppMappings) do
  local key = mapping[1]
  local app = mapping[2]
  hs.hotkey.bind(shyper, key, function()
    if (type(app) == 'string') then
      hs.application.open(app)
    elseif (type(app) == 'function') then
      app()
    else
      hs.logger.new('executer'):e('Invalid mapping for Hyper +', key)
    end
  end)
end

