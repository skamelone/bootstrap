numericMode = hs.hotkey.modal.new({}, 'F16')

local message = require('keyboard.status-message')
numericMode.statusMessage = message.new('Numeric Mode', typeMessage.numeric)

numericMode.entered = function()
  numericMode.statusMessage:show()
end

numericMode.exited = function()
  numericMode.statusMessage:hide()
end

-- Bind the given key to call the given function and exit Numeric mode
function numericMode.bindWith(mode, key, fn)
  mode:bind({}, key, function()
    fn()
  end)
end

numericMode:bindWith('space', function()
  hs.eventtap.keyStrokes('0')
end)

numericMode:bindWith('m', function()
  hs.eventtap.keyStrokes('1')
end)

numericMode:bindWith(',', function()
  hs.eventtap.keyStrokes('2')
end)

numericMode:bindWith('.', function()
  hs.eventtap.keyStrokes('3')
end)

numericMode:bindWith('j', function()
  hs.eventtap.keyStrokes('4')
end)

numericMode:bindWith('k', function()
  hs.eventtap.keyStrokes('5')
end)

numericMode:bindWith('l', function()
  hs.eventtap.keyStrokes('6')
end)

numericMode:bindWith('u', function()
  hs.eventtap.keyStrokes('7')
end)

numericMode:bindWith('i', function()
  hs.eventtap.keyStrokes('8')
end)

numericMode:bindWith('o', function()
  hs.eventtap.keyStrokes('9')
end)

numericMode:bindWith(';', function()
  hs.eventtap.keyStrokes('+')
end)

numericMode:bindWith('h', function()
  hs.eventtap.keyStrokes('-')
end)

-- Use Control+; to toggle Numeric Mode
hs.hotkey.bind({'left_control'}, ']', function()
  numericMode:enter()
end)
numericMode:bind({'left_control'}, ']', function()
  numericMode:exit()
end)
