local hyperex = require('hyperex')
local hx = hyperex.new('rightcmd')
hx:bind('a'):to('b')

