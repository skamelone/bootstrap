layoutMode = hs.hotkey.modal.new({}, 'F15')

local message = require('keyboard.status-message')
layoutMode.statusMessage = message.new('Layout', typeMessage.numeric)

layoutMode.entered = function()
  layoutMode.statusMessage:show()
end

layoutMode.exited = function()
  layoutMode.statusMessage:hide()
end

local status, windowMappings = pcall(require, 'config.windows-bindings')

if not status then
  windowMappings = require('config.windows-bindings')
end

local modifiers = windowMappings.modifiers
local showHelp  = windowMappings.showHelp
local trigger   = windowMappings.trigger
local mappings  = windowMappings.mappings


function getModifiersStr(modifiers)
  local modMap = { shift = '⇧', ctrl = '⌃', alt = '⌥', cmd = '⌘' }
  local retVal = ''

  for i, v in ipairs(modifiers) do
    retVal = retVal .. modMap[v]
  end

  return retVal
end

local msgStr = getModifiersStr(modifiers)
msgStr = 'Layout Mode'

for i, mapping in ipairs(mappings) do
  local modifiers, trigger, winFunction = table.unpack(mapping)
  local hotKeyStr = getModifiersStr(modifiers)

  if showHelp == true then
    if string.len(hotKeyStr) > 0 then
      msgStr = msgStr .. (string.format('\n%10s+%s => %s', hotKeyStr, trigger, winFunction))
    else
      msgStr = msgStr .. (string.format('\n%11s => %s', trigger, winFunction))
    end
  end

  layoutMode:bind(modifiers, trigger, function() os.execute(winFunction); layoutMode:exit(); end)
end

local message = require('keyboard.status-message')
layoutMode.statusMessage = message.new(msgStr, typeMessage.window)


-- Use Control+; to toggle Numeric Mode
hs.hotkey.bind(modifiers, trigger, function()
  layoutMode:enter()
end)
layoutMode:bind(modifiers, trigger, function()
  layoutMode:exit()
end)
