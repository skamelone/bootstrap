function bindCmd(mods, key, cmd)
    hs.hotkey.bind(mods, key, function() os.execute(cmd) end)
end

-- focus window
bindCmd({"alt"}, "h", "/usr/local/bin/yabai -m window --focus west")
bindCmd({"alt"}, "j", "/usr/local/bin/yabai -m window --focus south")
bindCmd({"alt"}, "k", "/usr/local/bin/yabai -m window --focus north")
bindCmd({"alt"}, "l", "/usr/local/bin/yabai -m window --focus east")

-- resize window
bindCmd({"alt"}, "a", "/usr/local/bin/yabai -m window --resize left:-20:0")
bindCmd({"alt"}, "c", "/usr/local/bin/yabai -m window --resize bottom:0:20")
bindCmd({"alt"}, "g", "/usr/local/bin/yabai -m window --resize right:20:0")
bindCmd({"alt"}, "e", "/usr/local/bin/yabai -m window --resize top:0:-20")

-- Full screen
bindCmd({"alt"}, "f", "/usr/local/bin/yabai -m window --toggle native-fullscreen")
bindCmd({"control", "option", "shift"}, "f", "/usr/local/bin/yabai -m window --toggle native-fullscreen")

-- Move window
bindCmd({"control", "option", "shift"}, "1", "/usr/local/bin/yabai -m window --space  1; /usr/local/bin/yabai -m space --focus 1")
bindCmd({"control", "option", "shift"}, "2", "/usr/local/bin/yabai -m window --space  2; /usr/local/bin/yabai -m space --focus 2")
bindCmd({"control", "option", "shift"}, "3", "/usr/local/bin/yabai -m window --space  3; /usr/local/bin/yabai -m space --focus 3")
bindCmd({"control", "option", "shift"}, "4", "/usr/local/bin/yabai -m window --space  4; /usr/local/bin/yabai -m space --focus 4")

-- Move window
bindCmd({"control", "option", "shift"}, "a", "/usr/local/bin/yabai -m window --swap west")
bindCmd({"control", "option", "shift"}, "g", "/usr/local/bin/yabai -m window --swap east")
bindCmd({"control", "option", "shift"}, "e", "/usr/local/bin/yabai -m window --swap north")
bindCmd({"control", "option", "shift"}, "c", "/usr/local/bin/yabai -m window --swap south")


-- Move window - Apple
bindCmd({"alt", "shift"}, "1", "/usr/local/bin/yabai -m window --space  1; /usr/local/bin/yabai -m space --focus 1")
bindCmd({"alt", "shift"}, "2", "/usr/local/bin/yabai -m window --space  2; /usr/local/bin/yabai -m space --focus 2")
bindCmd({"alt", "shift"}, "3", "/usr/local/bin/yabai -m window --space  3; /usr/local/bin/yabai -m space --focus 3")
bindCmd({"alt", "shift"}, "4", "/usr/local/bin/yabai -m window --space  4; /usr/local/bin/yabai -m space --focus 4")

-- Move window - Apple
bindCmd({"alt", "shift"}, "h", "/usr/local/bin/yabai -m window --swap west")
bindCmd({"alt", "shift"}, "l", "/usr/local/bin/yabai -m window --swap east")
bindCmd({"alt", "shift"}, "k", "/usr/local/bin/yabai -m window --swap north")
bindCmd({"alt", "shift"}, "j", "/usr/local/bin/yabai -m window --swap south")

