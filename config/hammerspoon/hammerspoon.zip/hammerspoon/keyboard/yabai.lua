function bindCmd(mods, key, cmd)
    hs.hotkey.bind(mods, key, function() os.execute(cmd) end)
end

-- Full screen
bindCmd({"control", "option", "shift"}, "f", "/usr/local/bin/yabai -m window --toggle native-fullscreen")

-- Move window
bindCmd({"control", "option", "shift"}, "1", "/usr/local/bin/yabai -m window --space  1; /usr/local/bin/yabai -m space --focus 1")
bindCmd({"control", "option", "shift"}, "2", "/usr/local/bin/yabai -m window --space  2; /usr/local/bin/yabai -m space --focus 2")
bindCmd({"control", "option", "shift"}, "3", "/usr/local/bin/yabai -m window --space  3; /usr/local/bin/yabai -m space --focus 3")
bindCmd({"control", "option", "shift"}, "4", "/usr/local/bin/yabai -m window --space  4; /usr/local/bin/yabai -m space --focus 4")

-- Move window
bindCmd({"control", "option", "shift"}, "a", "/usr/local/bin/yabai -m window --swap west")
bindCmd({"control", "option", "shift"}, "g", "/usr/local/bin/yabai -m window --swap east")
bindCmd({"control", "option", "shift"}, "e", "/usr/local/bin/yabai -m window --swap north")
bindCmd({"control", "option", "shift"}, "c", "/usr/local/bin/yabai -m window --swap south")

