export FZF_DEFAULT_OPTS='--height 40% --reverse --border'
export FZF_DEFAULT_OPTS='--extended'
export FZF_DEFAULT_COMMAND="fd --type f"
export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"
# export PATH=$PATH:$(go env GOPATH)/bin
export PATH=$PATH:/usr/local/mysql-8.0.21-macos10.15-x86_64/bin/:/opt/homebrew/bin/
