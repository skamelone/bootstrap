bindkey -v

bindkey '^r' fzf-history-widget-accept
bindkey '^u' fzf-cd-widget
bindkey '^o' fzf-file-widget

