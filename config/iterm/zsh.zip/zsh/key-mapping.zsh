bindkey -v

bindkey '^r' fzf-history-widget-accept
bindkey '^u' fzf-cd-widget
bindkey '^o' fzf-file-widget
bindkey -s '^d' 'fwo\n'
bindkey -s '^s' 'fwd\n'

