Dash
====

Dash extension for PopClip.