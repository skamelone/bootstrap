Instant Translate
-----------------

The original Instant Translate (a.k.a. Better Translate) was developed by [harmy](http://harmy.github.io).

Some time in March/April 2015 Google changed their back end which stopped the original version from working. (To be fair to Google, the original was skirting around the paid API using some undocumented endpoints.)

This new version (21 Apr 2015) was modified from the original by [chenggiant](https://github.com/chenggiant), to use the official Microsoft Translator API.

Further modifications made by Nick Moore.

----

Further updated with server-issued credentials 22 Apr 2015.
